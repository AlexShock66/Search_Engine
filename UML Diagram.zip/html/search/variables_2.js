var searchData=
[
  ['chars_5fread_5fcurrent_5fline_691',['chars_read_current_line',['../structnlohmann_1_1detail_1_1position__t.html#a74df94563dd32102152ceb8c6d9041d8',1,'nlohmann::detail::position_t']]],
  ['chars_5fread_5ftotal_692',['chars_read_total',['../structnlohmann_1_1detail_1_1position__t.html#a94cf85cd91d478c20ae143eba906ea1a',1,'nlohmann::detail::position_t']]]
];
