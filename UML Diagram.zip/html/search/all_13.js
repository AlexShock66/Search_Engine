var searchData=
[
  ['unflatten_353',['unflatten',['../classnlohmann_1_1basic__json.html#adea158bff8642202420898f6322da479',1,'nlohmann::basic_json']]],
  ['uninitialized_354',['uninitialized',['../classnlohmann_1_1detail_1_1lexer__base.html#aa3538cce439a2de6c7893e627b38c454a42dd1a73d072bb6bf3f494f22b15db8e',1,'nlohmann::detail::lexer_base']]],
  ['update_355',['update',['../classnlohmann_1_1basic__json.html#a377819905d567f6f523dcbc592cb6356',1,'nlohmann::basic_json::update(const_reference j)'],['../classnlohmann_1_1basic__json.html#a9f9e5f668474280acc9bd7f5410b9392',1,'nlohmann::basic_json::update(const_iterator first, const_iterator last)']]]
];
