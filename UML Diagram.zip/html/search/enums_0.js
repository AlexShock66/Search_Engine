var searchData=
[
  ['cbor_5ftag_5fhandler_5ft_736',['cbor_tag_handler_t',['../namespacenlohmann_1_1detail.html#a58bb1ef1a9ad287a9cfaf1855784d9ac',1,'nlohmann::detail']]]
];
