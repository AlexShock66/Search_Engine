var searchData=
[
  ['unflatten_680',['unflatten',['../classnlohmann_1_1basic__json.html#adea158bff8642202420898f6322da479',1,'nlohmann::basic_json']]],
  ['update_681',['update',['../classnlohmann_1_1basic__json.html#a377819905d567f6f523dcbc592cb6356',1,'nlohmann::basic_json::update(const_reference j)'],['../classnlohmann_1_1basic__json.html#a9f9e5f668474280acc9bd7f5410b9392',1,'nlohmann::basic_json::update(const_iterator first, const_iterator last)']]]
];
